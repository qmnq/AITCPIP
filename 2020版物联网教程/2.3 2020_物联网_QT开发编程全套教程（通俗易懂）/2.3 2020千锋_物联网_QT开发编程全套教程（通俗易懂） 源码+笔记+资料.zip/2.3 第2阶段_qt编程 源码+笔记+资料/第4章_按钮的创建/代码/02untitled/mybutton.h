#ifndef MYBUTTON_H
#define MYBUTTON_H

#include <QPushButton>
class mybutton : public QPushButton
{
public:
    mybutton();
    ~mybutton();
};

#endif // MYBUTTON_H
