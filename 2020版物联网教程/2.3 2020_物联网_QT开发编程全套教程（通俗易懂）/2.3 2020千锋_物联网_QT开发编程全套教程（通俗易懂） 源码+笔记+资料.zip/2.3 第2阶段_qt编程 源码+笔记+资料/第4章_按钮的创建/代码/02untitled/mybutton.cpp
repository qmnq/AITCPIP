#include "mybutton.h"
#include <QDebug>
mybutton::mybutton()
{

}

mybutton::~mybutton()
{

        qDebug()<< "mybutton的析构";

}
