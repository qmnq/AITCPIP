#include <QApplication> //QT的框架头文件
#include <QWidget>
#include <QDebug>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);//QT的框架初始化
    //QWidget
    QWidget win;
    win.resize(400,300);
    win.setWindowTitle("hello qt");
    win.show();//显示
    qDebug()<<"hello";

    return a.exec();//a.exec()作用是让程序不死 类似于while(1)循环 循环检测事件的产生
 }
