#include "widget.h"
#include <QApplication>
#include "smallwidget.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w;
    w.show();
   // smallwidget s;
  //  s.show();

    return a.exec();
}
