#include "widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{//this
    //代码可以写在这里 设置窗口属性
    this->setWindowTitle("hello qt");
    //this->resize(600,400);
    this->setFixedSize(600,400);


}

Widget::~Widget()
{

}
