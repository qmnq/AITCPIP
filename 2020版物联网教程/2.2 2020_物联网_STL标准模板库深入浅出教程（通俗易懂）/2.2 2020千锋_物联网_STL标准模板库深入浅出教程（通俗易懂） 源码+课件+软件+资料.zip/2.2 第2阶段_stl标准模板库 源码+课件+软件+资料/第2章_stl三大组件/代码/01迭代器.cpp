#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string.h>
#include <string>
#include <vector>
#include <algorithm>
using namespace std;
void print(int a)
{
	cout << a << endl;
}
void  test01()
{
	vector<int>  v;
	v.push_back(2);
	v.push_back(4);
	v.push_back(5);
	v.push_back(3);
	//����Ҫ���������ڵ�Ԫ�� ��Ҫ�õ�������Ԫ�صĵ�����(ָ��)
	vector<int>::iterator it_start = v.begin();
	vector<int>::iterator it_end  = v.end();
	/*for (; it_start != it_end; it_start++)
	{
		cout << *it_start << " ";
	
	}
	cout << endl;*/
	for_each(it_start, it_end, print);

}


class Person
{
public:
	Person(int  age)
	{
		this->age = age;
	}
	int age;
};
void  print_person(Person &p)
{
	cout << p.age << endl;
}
void test02()
{
	Person p1(1);
	Person p2(2);
	Person p3(3);
	Person p4(4);

	vector<Person > v;
	v.push_back(p1);
	v.push_back(p2);
	v.push_back(p3);
	v.push_back(p4);
	vector<Person>::iterator it_start = v.begin();
	vector<Person>::iterator it_end = v.end();
	for (; it_start != it_end; it_start++)
	{
		//* it_start  == Person
		print_person(*it_start);
	}
	
}

void  test03()
{
	vector<  vector<int> > v;
	vector<int> v1;
	vector<int> v2;
	vector<int> v3;
	for (int i = 0; i < 3; i++)
	{
		v1.push_back(i);
		v2.push_back(i + 10);
		v3.push_back(i + 100);
	}
	v.push_back(v1);
	v.push_back(v2);
	v.push_back(v3);
	vector<  vector<int> >::iterator it = v.begin();
	for (; it != v.end(); it++)
	{
		//*it  �õ�����vector<int>
		vector<int>::iterator it1 = (*it).begin();
		vector<int>::iterator it2 = (*it).end();
		for (; it1 != it2; it1++)
		{
			cout << *it1 << endl;
		}
		
	}


}
int  main()
{
	test03();
	return 0;
}