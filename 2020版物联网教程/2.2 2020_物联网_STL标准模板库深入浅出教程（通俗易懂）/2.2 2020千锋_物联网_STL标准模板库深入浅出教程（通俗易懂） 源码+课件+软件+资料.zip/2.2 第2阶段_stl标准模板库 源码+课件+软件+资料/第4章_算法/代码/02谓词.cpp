#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string.h>
#include <string>
#include <vector>
#include <algorithm>
using namespace std;
class Print
{
public:
	void  operator()(int a)
	{
		cout << a << endl;
	}
};
bool greater2(int a)
{
	return a > 2;
}
void test01()
{
	vector<int> v;
	v.push_back(1);
	v.push_back(3);
	v.push_back(2);
	v.push_back(5);
	vector<int>::iterator it =  find_if(v.begin(), v.end(), greater2);
	if (it != v.end())
	{
		cout << *it << endl;
	}
	for_each(v.begin(), v.end(), Print());

}

int main()
{
	test01();
	return 0;
}