#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <string.h>
#include <string>
#include <vector>
#include <algorithm>
#include <functional>
using namespace std;
void  test01()
{
	negate<int> p;
	cout << p(5) << endl;
	cout << negate<int>()(2) << endl;

}
void  test02()
{
	cout << plus<int>()(2, 3) << endl;
}
class Print
{
public:
	void  operator()(int a)
	{
		cout << a << endl;
	}
};
void test03()
{
	vector<int> v;
	v.push_back(1);
	v.push_back(3);
	v.push_back(2);
	v.push_back(5);
	//sort(v.begin(), v.end(), greater<int>());
	sort(v.begin(), v.end(),less<int>());
	for_each(v.begin(), v.end(), Print());

}
int main()
{
	test03();
	return 0;
}