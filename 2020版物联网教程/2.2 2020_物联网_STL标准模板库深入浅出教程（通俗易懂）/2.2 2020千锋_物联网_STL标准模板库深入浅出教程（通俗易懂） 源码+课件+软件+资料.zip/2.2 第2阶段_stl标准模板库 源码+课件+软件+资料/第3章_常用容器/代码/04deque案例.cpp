#include <iostream>
#include <string>
#include <vector>
#include <deque>
#include <time.h>
#include <algorithm>
using namespace std;
class player
{
public:
	player() {}
	player(string  name, int score)
	{
		this->name = name;
		this->score = score;
	}
	string  name;
	int score;
};
void Init_player(vector<player> &v)
{
	string str = "ABCDE";
	for (int i = 0; i < 5; i++)
	{
		string strname(1, str[i]);// strname =  'A' 0   'B' 0
		player tmp(strname, 0);
		v.push_back(tmp);
	}
}
void print_player(vector<player> &v)
{
	for (vector<player>::iterator it = v.begin(); it != v.end(); it++)
	{
		//cout << it->name << " " << it->score << endl;
		cout << (*it).name << " " << (*it).score << endl;
	}

}
void start_play(vector<player> &v)
{
	srand((unsigned int)time(NULL));
	deque<int> d;
	for (vector<player>::iterator it = v.begin(); it != v.end(); it++)
	{
		// *it ==> player

		for (int i = 0; i < 10; i++)
		{
			d.push_back(60 + rand() % 41);
		}
		//ȥ����ߺ����
		sort(d.begin(), d.end());
		d.pop_back();
		d.pop_front();
		int sum = 0;
		/*for (int i = 0; i < d.size(); i++)
		{
		sum += d[i];
		}*/
		for (deque<int>::iterator it1 = d.begin(); it1 != d.end(); it1++)
		{
			sum += *it1;
		}
		int aver = sum / d.size();

		it->score = aver;
		d.clear();

	}

}
int  main()
{
	vector<player> v;
	Init_player(v);
	print_player(v);
	start_play(v);
	print_player(v);
	return 0;
}